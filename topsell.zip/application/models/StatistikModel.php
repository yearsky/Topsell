<?php

class StatistikModel extends MY_Model
{
	protected $table 	= "statistik";
}
