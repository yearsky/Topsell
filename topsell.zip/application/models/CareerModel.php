<?php

class CareerModel extends MY_Model
{
	protected $table 	= "career";

}
